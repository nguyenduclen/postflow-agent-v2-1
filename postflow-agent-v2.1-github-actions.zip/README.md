# PostFlow Agent v2.1

Android companion for PostFlow. This build contains a real Android application, manifest, launcher activity, and Accessibility Service. It does not run Chromium/Playwright on the hosting server and does not read Facebook passwords or cookies.

Default PostFlow URL: https://postflow.phutungmaykubota.vn

After installation: open the app → save URL/token → open Accessibility settings → enable PostFlow Agent.
