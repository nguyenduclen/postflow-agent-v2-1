package vn.phutungmaykubota.postflowagent;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends android.app.Activity {
    EditText url, token; TextView status; SharedPreferences prefs;
    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main);
        prefs=getSharedPreferences("postflow",0); url=findViewById(R.id.url); token=findViewById(R.id.token); status=findViewById(R.id.status);
        url.setText(prefs.getString("url","https://postflow.phutungmaykubota.vn")); token.setText(prefs.getString("token",""));
        findViewById(R.id.save).setOnClickListener(v->{ prefs.edit().putString("url",url.getText().toString().trim()).putString("token",token.getText().toString().trim()).apply(); status.setText("Đã lưu cấu hình."); });
        findViewById(R.id.accessibility).setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        findViewById(R.id.test).setOnClickListener(v->new Thread(()->{ try { String u=prefs.getString("url",""); HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection(); c.setConnectTimeout(5000); c.setReadTimeout(5000); int code=c.getResponseCode(); runOnUiThread(()->status.setText("PostFlow HTTP: "+code)); c.disconnect(); } catch(Exception e){ runOnUiThread(()->status.setText("Kết nối lỗi: "+e.getClass().getSimpleName())); }}).start());
    }
}
