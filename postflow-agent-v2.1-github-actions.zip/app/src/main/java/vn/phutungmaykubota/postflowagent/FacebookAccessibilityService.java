package vn.phutungmaykubota.postflowagent;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class FacebookAccessibilityService extends AccessibilityService {
    private final Handler h=new Handler(Looper.getMainLooper()); private long last=0;
    @Override public void onAccessibilityEvent(AccessibilityEvent e){
        CharSequence p=e.getPackageName(); if(p==null || !"com.android.chrome".contentEquals(p)) return;
        long now=System.currentTimeMillis(); if(now-last<1500) return; last=now;
        CharSequence cls=e.getClassName(); sendStatus(cls==null?"chrome":"chrome");
    }
    private void sendStatus(String state){
        SharedPreferences p=getSharedPreferences("postflow",0); String base=p.getString("url",""); String token=p.getString("token","");
        if(base.isEmpty()) return; new Thread(()->{ try{
            String endpoint=base.replaceAll("/+$","")+"/worker_api.php";
            HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(4000); c.setReadTimeout(4000); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json"); if(!token.isEmpty()) c.setRequestProperty("Authorization","Bearer "+token);
            String body="{\"event\":\"chrome_active\",\"state\":\""+state+"\"}"; try(OutputStream o=c.getOutputStream()){o.write(body.getBytes(java.nio.charset.StandardCharsets.UTF_8));} c.getResponseCode(); c.disconnect();
        }catch(Exception ignored){} }).start();
    }
    @Override public void onInterrupt(){}
}
